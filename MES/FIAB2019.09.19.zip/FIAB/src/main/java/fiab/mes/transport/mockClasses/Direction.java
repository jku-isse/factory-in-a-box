package fiab.mes.transport.mockClasses;

public class Direction {
	private String direction;
	
	public Direction(String direction) {
		this.direction = direction;
	}

	public String getString() {
		return direction;
	}

}
